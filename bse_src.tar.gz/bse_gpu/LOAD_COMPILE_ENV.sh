#!/bin/sh

module load PrgEnv-nvidia
module load cray-fftw
module load cray-libsci
module load cudatoolkit
module load craype-accel-nvidia80
