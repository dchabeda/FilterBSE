#include "fd.h"
#include "aux.h"

#include "mod_init.h"
#include "spin.h"
#include "mod_pot.h"
#include "mod_dipole.h"
#include "mod_kernel.h"