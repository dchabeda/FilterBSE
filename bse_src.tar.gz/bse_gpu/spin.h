#include "fd.h"
#include "aux.h"

void qp_spin_frac(
    double*          psi_qp,
    double*          eig_vals,
    index_st*        ist,
    par_st*          par,
    flag_st*         flag,
    parallel_st*     parallel
);