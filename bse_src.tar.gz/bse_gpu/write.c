/****************************************************************************/
/* This file does the printing for the program */

#include "fd.h"

/****************************************************************************/

void write_cube_file(double *rho, grid_st *grid, char *fileName) {
  /*****************************************************************
  * This function prints out cube files to visualize wavefunctions *
  * inputs: [double *rho] is a pointer to an ngrid long array      *
  *         [grid_st *grid] is a pointer to the grid struct        *
  *         [char *fileName] is a pointer to the output file name  *
  * outputs: void                                                  *
  ******************************************************************/ 

  FILE *pf, *pConfFile;
  long jgrid, iX, iY, iZ, iYZ, natoms, atomType;
  double x, y, z;
  char line[80], atomSymbol[10];


  pConfFile = fopen("conf.dat", "r");
  fscanf(pConfFile, "%ld", &natoms);
  pf = fopen(fileName, "w");
  fprintf(pf, "CUBE FILE\n");
  fprintf(pf, "OUTER LOOP: X, MIDDLE LOOP: Y, INNER LOOP: Z\n");
  fprintf(pf, "%5li%12.6f%12.6f%12.6f\n", natoms, grid->xmin, grid->ymin, grid->zmin);
  fprintf(pf, "%5li%12.6f%12.6f%12.6f\n", grid->nx, grid->dx, 0.0, 0.0);
  fprintf(pf, "%5li%12.6f%12.6f%12.6f\n", grid->ny, 0.0, grid->dy, 0.0);
  fprintf(pf, "%5li%12.6f%12.6f%12.6f\n", grid->nz, 0.0, 0.0, grid->dz);
  fgets(line, 80, pConfFile); 
  while(fgets(line, 80, pConfFile) != NULL) {
    sscanf(line, "%2s %lf %lf %lf %ld %*lf", (char*)&atomSymbol, &x, &y, &z, &atomType);
    
    //TODO: make sane atom handling.... 
    if (! strcmp(atomSymbol, "Cd")) { 
      atomType = 48;
    }
    else if (! strcmp(atomSymbol, "S")) {  
      atomType = 16;
    }
    else if (! strcmp(atomSymbol, "Se")) { 
      atomType = 34;
    }
    else if (! strcmp(atomSymbol, "Zn")) {
      atomType = 30;
    }
    else if (! strcmp(atomSymbol, "Te")) {
      atomType = 52;
    }
  	else if (! strcmp(atomSymbol, "C")) {
  	  atomType = 6;
  	}
    else if (! strcmp(atomSymbol, "Si")) {
	  atomType = 14;
    }
    else if (! strcmp(atomSymbol, "Cs")) {
    atomType = 55;
    }
    else if (! strcmp(atomSymbol, "Pb")) {
    atomType = 82;
    }
    else if (! strcmp(atomSymbol, "I")) {
    atomType = 53;
    }
    else { 
      atomType = 1; 
    }
    fprintf(pf, "%5li%12.6f%12.6f%12.6f%12.6f\n", atomType, 0.0, x, y, z);
  }
  for (iX = 0; iX < grid->nx; iX++) {
    for (iY = 0; iY < grid->ny; iY++) {
      for (iZ = 0; iZ < grid->nz; iZ++) {
        iYZ = grid->nx * (grid->ny * iZ + iY);
        jgrid = iYZ + iX;
        fprintf(pf, "%12.5g ", rho[jgrid]);
        if (iZ % 6 == 5) {
          fprintf(pf, "\n");
        }
      }
      fprintf(pf, "\n");
    }
  }
  fclose(pConfFile);
  fclose(pf);

  return;
}

/****************************************************************************/
// prints out current time to stdout 
 
void write_current_time(FILE *pf) {
  time_t startTime;

  startTime = time(NULL);
  fprintf(pf,"%s", ctime(&startTime));

  return;
}

/****************************************************************************/

void write_separation(FILE *pf, char *top_bttm) {
  /*****************************************************************
  * This function prints asterisk separation lines in stdout       *
  * inputs:                                                        *
  *   [FILE *pf] pointer to output file stream                     *
  *   [char *top_bttm] pointer to char for top/bottom formatting   *
  * outputs: void                                                  *
  ******************************************************************/

  const char top_key[] = "T";
  const char bttm_key[] = "B";

  if (strcmp(top_bttm, top_key) == 0) {
    fprintf(pf, "\n\n******************************************************************************\n");
  } else if (strcmp(top_bttm, bttm_key) == 0) {
    fprintf(pf, "\n******************************************************************************\n");
  } else {
    fprintf(stderr, "Invalid string supplied to write_separation. Exiting!\n");
    exit(EXIT_FAILURE);
  }

  return;
}

/****************************************************************************/

void write_state_dat(zomplex *psi, long n_elems, char* fileName){
  FILE *pf;
  long i;

  pf = fopen(fileName, "w");
  for (i = 0; i < n_elems; i++){
    fprintf(pf, "%lg %lg\n", psi[i].re, psi[i].im);
  }
  fclose(pf);
  
}

/****************************************************************************/
