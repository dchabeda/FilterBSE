#!/bin/sh

module load PrgEnv-intel/8.3.3
module load fast-mkl-amd/fast-mkl-amd
module load cray-fftw/3.3.10.3
